function [Pi,X]=ExerciceN3(x0,p,T)
n=T/2; % D'apr�s l'�nonc� de l'exercice T dois �tre en secondes.
X=Particule(x0,p,n);
Pi=ProbaPosition(X,n);
end

function x=Particule(x0,p,n)
x(1)=x0;
for i=1:n
    u=random('unif',0,1);
    if u<p(1)
        x(i+1)=x(i)+1;
    elseif u<p(2)
        x(i+1)=x(i);
    else
        x(i+1)=x(i)-1;
    end
end
end

function Pi=ProbaPosition(X,n)
a=min(X);
b=max(X);
P=zeros(1,b-a+1);
for i=a:b
    for j=1:n
        if X(j)==i
            P(i-a+1)=P(i-a+1)+1;
        end
    end
end
Pi=[a:b; P/n];
end
