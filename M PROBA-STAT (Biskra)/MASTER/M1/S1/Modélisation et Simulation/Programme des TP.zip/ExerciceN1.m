function [Ihat]=ExerciceN1(a,b,n,mc,exemple)
switch exemple
    case 1
        [Ihat]=Exemple1(a,b,n,mc); % Estimation du premier int�grale
    case 2
        [Ihat]=Exemple2(a,b,n,mc); % Estimation du deuxi�me int�grale
    case 3
        [Ihat]=Exemple3(n,mc);     % Estimation de la valeurs de pi.
end

end


function [Ihat]=Exemple1(a,b,n,mc)
S=(b-a)*1;% Surface du rectangle
for j=1:mc
    Nbr=0;
    for i=1:n
        x=random('unif',a,b);
        y=random('unif',0,1);
        if (y<exp(-x^2))
            Nbr=Nbr+1;
        end
    end
    I(j)=(Nbr/n)*S;
end
Ihat=mean(I);
end

function [Ihat]=Exemple2(a,b,n,mc)
S=(b-a)*0.35;% Surface du rectangle
for j=1:mc
    Nbr=0;
    for i=1:n
        x=random('unif',a,b);
        y=random('unif',0,0.35);
        if (y<(log(sin(x)+cos(x))))
            Nbr=Nbr+1;
        end
    end
    I(j)=(Nbr/n)*S;
end
Ihat=mean(I);
end

function [Pi_hat]=Exemple3(n,mc)
for j=1:mc
    Nbr=0;
    for i=1:n
        x=random('unif',0,1);
        y=random('unif',0,1);
        if ((x^2+y^2)<1)
            Nbr=Nbr+1;
        end
    end
    I(j)=(Nbr/n)*4;
end
Pi_hat=mean(I);
end